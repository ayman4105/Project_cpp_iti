#pragma once 

enum class log_type{
    Console_log,
    File_log,
    Sink_log
};