#pragma once

enum class severity_level
{
    Warning,
    Critical,
    Info
};