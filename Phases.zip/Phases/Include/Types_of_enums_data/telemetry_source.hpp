#pragma once

// Types of telemetry  sources
enum class enum_telem_src
{
    CPU,
    GPU,
    RAM
};