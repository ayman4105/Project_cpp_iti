#pragma once 


enum class sinks_type{
    Console_sink,
    Soket_sink
};